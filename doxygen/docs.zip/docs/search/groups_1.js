var searchData=
[
  ['adc_20전역_20변수_0',['ADC 전역 변수',['../group___a_d_c___variables.html',1,'']]]
];
