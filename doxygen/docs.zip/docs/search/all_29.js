var searchData=
[
  ['핸들_20전역_20변수_0',['타이머 핸들 전역 변수',['../group___t_i_m___handles.html',1,'']]]
];
