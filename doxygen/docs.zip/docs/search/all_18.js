var searchData=
[
  ['기준_20전역_20변수_0',['3상 전압 기준 전역 변수',['../group___voltage_ref.html',1,'']]]
];
