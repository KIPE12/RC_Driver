var group___t_i_m___handles =
[
    [ "htim1", "group___t_i_m___handles.html#ga25fc663547539bc49fecc0011bd76ab5", null ],
    [ "htim15", "group___t_i_m___handles.html#ga859a9bb217bb4010bb2bffb6881478c0", null ],
    [ "htim2", "group___t_i_m___handles.html#ga2c80fd5510e2990a59a5c90d745c716c", null ]
];