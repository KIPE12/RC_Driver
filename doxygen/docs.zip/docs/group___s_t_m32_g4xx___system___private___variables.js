var group___s_t_m32_g4xx___system___private___variables =
[
    [ "AHBPrescTable", "group___s_t_m32_g4xx___system___private___variables.html#ga6e1d9cd666f0eacbfde31e9932a93466", null ],
    [ "APBPrescTable", "group___s_t_m32_g4xx___system___private___variables.html#ga5b4f8b768465842cf854a8f993b375e9", null ],
    [ "SystemCoreClock", "group___s_t_m32_g4xx___system___private___variables.html#gaa3cd3e43291e81e795d642b79b6088e6", null ]
];