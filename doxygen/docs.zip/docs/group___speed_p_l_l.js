var group___speed_p_l_l =
[
    [ "integ_Thetar_PLL", "group___speed_p_l_l.html#gae5a48e70b8cf30f644d2659922be401e", null ],
    [ "Ki_SPD_PLL", "group___speed_p_l_l.html#gaf264b9081a097b39ddf858991455616a", null ],
    [ "Kp_SPD_PLL", "group___speed_p_l_l.html#gad694603a0b14177a055a2a0b9aa15059", null ],
    [ "W_SPD_PLL", "group___speed_p_l_l.html#gadc87dae95abcb03a026eb0d0dfce2c52", null ]
];