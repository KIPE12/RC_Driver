var searchData=
[
  ['offset_0',['Offset',['../adc_8c.html#a5c5c41c37d32d75b9a5844f877762629',1,'adc.c']]],
  ['openloopcontrol_1',['OpenLoopControl',['../inv_8c.html#a964ec348ab2be811f76c85501ac14208',1,'inv.c']]]
];
