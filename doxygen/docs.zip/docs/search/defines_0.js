var searchData=
[
  ['adc12bit_0',['ADC12BIT',['../adc_8c.html#a6468e4f5307fe3787196c448082edfa4',1,'adc.c']]],
  ['adc_5fresol_1',['ADC_RESOL',['../adc_8c.html#abb6c4ee522ebd1493a24229158ba9289',1,'adc.c']]]
];
