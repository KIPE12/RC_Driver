var searchData=
[
  ['구성_0',['하드웨어 구성',['../index.html#hw',1,'']]],
  ['구조_1',['소프트웨어 구조',['../index.html#sw',1,'']]]
];
