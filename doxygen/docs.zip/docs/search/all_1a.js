var searchData=
[
  ['변수_0',['변수',['../group___speed_p_l_l.html',1,'속도 PLL 전역 변수'],['../group___t_i_m___handles.html',1,'타이머 핸들 전역 변수'],['../group___voltage_ref.html',1,'3상 전압 기준 전역 변수'],['../group___a_d_c___variables.html',1,'ADC 전역 변수']]]
];
