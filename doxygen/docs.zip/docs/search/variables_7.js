var searchData=
[
  ['ia_5farr_0',['Ia_arr',['../group___a_d_c___variables.html#gaa84d1b34b367ee7ae68cfdb9161260cc',1,'adc.c']]],
  ['integ_5fthetar_5fpll_1',['integ_Thetar_PLL',['../group___speed_p_l_l.html#gae5a48e70b8cf30f644d2659922be401e',1,'variable.c']]],
  ['inv_2',['INV',['../inv_8c.html#a5b799dff3aee9e48ae67cfe1f9075e30',1,'inv.c']]]
];
