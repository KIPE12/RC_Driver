var group___voltage_ref =
[
    [ "Van", "group___voltage_ref.html#ga30c95cfd601124d7bb6a4535bdeb1f72", null ],
    [ "Vbn", "group___voltage_ref.html#ga2f2a0c510c5b72110e5e3835c1c62555", null ],
    [ "Vcn", "group___voltage_ref.html#ga99d72ed4a63ffab24762fc939a2b9c7d", null ],
    [ "Vdse_ref_set", "group___voltage_ref.html#ga2fd0eefeac2ca9b75b92696acff79191", null ],
    [ "Vdss_ref_set", "group___voltage_ref.html#ga94ab3777ddd48161a4945f405c0359a6", null ],
    [ "Vqse_ref_set", "group___voltage_ref.html#gad30cf7ec93e4213c93b2ed4bf3e0ad18", null ],
    [ "Vqss_ref_set", "group___voltage_ref.html#ga8bf179fb2264726c2d6dc40618e56365", null ]
];