var searchData=
[
  ['ki_5fspd_5fpll_0',['Ki_SPD_PLL',['../group___speed_p_l_l.html#gaf264b9081a097b39ddf858991455616a',1,'variable.c']]],
  ['kp_5fspd_5fpll_1',['Kp_SPD_PLL',['../group___speed_p_l_l.html#gad694603a0b14177a055a2a0b9aa15059',1,'variable.c']]]
];
