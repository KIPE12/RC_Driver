var speed__observer_8c =
[
    [ "EXT_SS_Sync", "speed__observer_8c.html#abaa786059f3014de411996ce837e3d61", null ],
    [ "initExtended_Sensorless_Synchronous_Frame", "speed__observer_8c.html#a7bb91d6ba879e229823d84200e61de2d", null ],
    [ "InitSpeedObserver_", "speed__observer_8c.html#a69c4e8e965006dc08a941b3778962d4a", null ],
    [ "SpeedObserver_4_34", "speed__observer_8c.html#a8f5b08ab903b8aed4b6acc456b12804d", null ],
    [ "SpeedObserver_4_35", "speed__observer_8c.html#afecd3b4028d587d06f5acc2cb78ec17b", null ],
    [ "EXT_1", "speed__observer_8c.html#aaac3af89e1dd9944b6bccef174d4250b", null ]
];