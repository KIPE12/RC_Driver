var indexSectionsWithContent =
{
  0: "3_abcdefghikmnoprstuvw개구기모변상소속시알운전제지클타프플하핸",
  1: "acfgimstv",
  2: "_abcdeghimnoprstuv",
  3: "_acdefhikmprstvw",
  4: "a",
  5: "3acps기모변속전제타플핸",
  6: "rt개구모상소시알운제지클프하"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "파일들",
  2: "함수",
  3: "변수",
  4: "매크로",
  5: "그룹들",
  6: "페이지들"
};

