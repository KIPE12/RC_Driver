var searchData=
[
  ['시스템_20클럭_0',['시스템 클럭',['../index.html#clk',1,'']]]
];
