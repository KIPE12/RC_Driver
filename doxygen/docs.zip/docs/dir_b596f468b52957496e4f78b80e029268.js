var dir_b596f468b52957496e4f78b80e029268 =
[
    [ "adc.c", "adc_8c.html", "adc_8c" ],
    [ "control.c", "control_8c.html", "control_8c" ],
    [ "fault.c", "fault_8c.html", "fault_8c" ],
    [ "flag.c", "flag_8c.html", "flag_8c" ],
    [ "gpio.c", "gpio_8c.html", "gpio_8c" ],
    [ "inv.c", "inv_8c.html", "inv_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "speed_observer.c", "speed__observer_8c.html", "speed__observer_8c" ],
    [ "stm32g4xx_hal_msp.c", "stm32g4xx__hal__msp_8c.html", "stm32g4xx__hal__msp_8c" ],
    [ "stm32g4xx_it.c", "stm32g4xx__it_8c.html", "stm32g4xx__it_8c" ],
    [ "syscalls.c", "syscalls_8c.html", "syscalls_8c" ],
    [ "sysmem.c", "sysmem_8c.html", "sysmem_8c" ],
    [ "system_stm32g4xx.c", "system__stm32g4xx_8c.html", "system__stm32g4xx_8c" ],
    [ "tim.c", "tim_8c.html", "tim_8c" ],
    [ "variable.c", "variable_8c.html", "variable_8c" ]
];