var control_8c =
[
    [ "Control", "control_8c.html#afb486c446e28753e3dca5112dfdc8264", null ],
    [ "ControlCnt", "control_8c.html#a8dde33cdd74f2fd5bc110c7986794411", null ],
    [ "hadc1", "control_8c.html#a22b804736f5648d52f639b2647d4ed13", null ],
    [ "T_buffer", "control_8c.html#aee4f58524acc5e1a9386b2e9223e4846", null ]
];