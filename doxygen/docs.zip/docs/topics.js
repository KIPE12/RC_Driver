var topics =
[
    [ "ADC 전역 변수", "group___a_d_c___variables.html", "group___a_d_c___variables" ],
    [ "타이머 핸들 전역 변수", "group___t_i_m___handles.html", "group___t_i_m___handles" ],
    [ "제어 모드 플래그", "group___control_mode.html", "group___control_mode" ],
    [ "속도 PLL 전역 변수", "group___speed_p_l_l.html", "group___speed_p_l_l" ],
    [ "3상 전압 기준 전역 변수", "group___voltage_ref.html", "group___voltage_ref" ],
    [ "CMSIS", "group___c_m_s_i_s.html", "group___c_m_s_i_s" ]
];