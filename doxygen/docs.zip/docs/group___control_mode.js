var group___control_mode =
[
    [ "Align_done", "group___control_mode.html#gac8cf438350a0d309f204837cbdfa492a", null ],
    [ "Theta_mode", "group___control_mode.html#ga5e542439936627687d1a27ac7b6b50c2", null ]
];