var searchData=
[
  ['variable_2ec_0',['variable.c',['../variable_8c.html',1,'']]]
];
