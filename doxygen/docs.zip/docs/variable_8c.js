var variable_8c =
[
    [ "Align_done", "group___control_mode.html#gac8cf438350a0d309f204837cbdfa492a", null ],
    [ "integ_Thetar_PLL", "group___speed_p_l_l.html#gae5a48e70b8cf30f644d2659922be401e", null ],
    [ "Ki_SPD_PLL", "group___speed_p_l_l.html#gaf264b9081a097b39ddf858991455616a", null ],
    [ "Kp_SPD_PLL", "group___speed_p_l_l.html#gad694603a0b14177a055a2a0b9aa15059", null ],
    [ "Theta_mode", "group___control_mode.html#ga5e542439936627687d1a27ac7b6b50c2", null ],
    [ "Van", "group___voltage_ref.html#ga30c95cfd601124d7bb6a4535bdeb1f72", null ],
    [ "Vbn", "group___voltage_ref.html#ga2f2a0c510c5b72110e5e3835c1c62555", null ],
    [ "Vcn", "group___voltage_ref.html#ga99d72ed4a63ffab24762fc939a2b9c7d", null ],
    [ "Vdse_ref_set", "group___voltage_ref.html#ga2fd0eefeac2ca9b75b92696acff79191", null ],
    [ "Vdss_ref_set", "group___voltage_ref.html#ga94ab3777ddd48161a4945f405c0359a6", null ],
    [ "Vqse_ref_set", "group___voltage_ref.html#gad30cf7ec93e4213c93b2ed4bf3e0ad18", null ],
    [ "Vqss_ref_set", "group___voltage_ref.html#ga8bf179fb2264726c2d6dc40618e56365", null ],
    [ "W_SPD_PLL", "group___speed_p_l_l.html#gadc87dae95abcb03a026eb0d0dfce2c52", null ]
];