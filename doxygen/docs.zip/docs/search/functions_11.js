var searchData=
[
  ['voltageinjection_5fsquarewave_0',['VoltageInjection_SquareWave',['../inv_8c.html#aedf8f86f640274dface77130a3d50207',1,'inv.c']]],
  ['voltageopenloopcontrol_1',['VoltageOpenLoopControl',['../inv_8c.html#aefbd0b8bc957317d7f22f0db0185683d',1,'inv.c']]],
  ['vref_5fgencontrol_2',['Vref_GenControl',['../inv_8c.html#a01248186cec9f4dadc54e4c94be940cf',1,'inv.c']]]
];
