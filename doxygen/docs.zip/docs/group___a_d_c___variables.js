var group___a_d_c___variables =
[
    [ "ADC1_Offset", "group___a_d_c___variables.html#gaaf7ce8ada81ed29a8dc65c3e5e37dc9f", null ],
    [ "ADC1_Offset_sum", "group___a_d_c___variables.html#gad15e099727465664d340076de7f99b54", null ],
    [ "ADC1_Result", "group___a_d_c___variables.html#ga7a716cd4960c2c53daedb424e347c545", null ],
    [ "adc1Val", "group___a_d_c___variables.html#ga3f46ad79f65150aec6105a862cf32624", null ],
    [ "ADCgain", "group___a_d_c___variables.html#ga30578536ba1b4f97bf46c3e23a4656af", null ],
    [ "AdInitFlag", "group___a_d_c___variables.html#ga734b67f14f678f4b701be37706729cd0", null ],
    [ "AdOffCalcCnt", "group___a_d_c___variables.html#ga263585f5810892154827fe50fa03970f", null ],
    [ "Ia_arr", "group___a_d_c___variables.html#gaa84d1b34b367ee7ae68cfdb9161260cc", null ],
    [ "scale_comp", "group___a_d_c___variables.html#ga179af1226d9481eedeaa735e688c4553", null ],
    [ "store_cnt", "group___a_d_c___variables.html#ga62322c9b26bf52d62a48597667468e2e", null ],
    [ "store_flag", "group___a_d_c___variables.html#gaefc0d46c6253b25ffa506d5430abe433", null ]
];